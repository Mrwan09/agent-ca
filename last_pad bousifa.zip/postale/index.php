
<!DOCTYPE html>
<html lang="fr">
    <head data-template="loginpage"><meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>














<meta name="robots" content="index, follow"/>



<link rel="canonical" href="https://www.labanquepostale.fr/particulier/connexion-espace-client.html"/>








    
    
    <link rel="stylesheet" href="assets/fonts.css" type="text/css">

</meta>



    
    
    
<link rel="stylesheet" href="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/sitepublic/clientlibs/base.min.ba6767628935b1b170a00fbed52ebf1a.css" type="text/css">





<meta name="env" content="production"/>



    <!-- TAG COMMANDER START //-->
    <script type="text/javascript">
        var url = window.location.href;
        var pathname = window.location.pathname;
        var lastIndex = pathname.substring(pathname.lastIndexOf('/') + 1);
        var pagename = lastIndex.slice(0, lastIndex.indexOf("."));

        function getMeta(metaName) {
          var metas = document.getElementsByTagName('meta');
          for (let i = 0; i < metas.length; i++) {
            if (metas[i].getAttribute('property') === metaName || metas[i].getAttribute('name') === metaName) {
              return metas[i].getAttribute('content');
            }
          }
          return '';
        }
        var pageMetaName = getMeta("og:title");
        var env = getMeta("env");

        var tc_vars = {
            cms_template_name: '/apps/labanquepostale/sitepublic/templates/loginpage',
            cms_page_name: window.location.pathname,
            cms_page_title: pagename  !== "" ? pagename : pageMetaName,
            override_page_name: "",
            xiti_xtpage: 'connexion-espace-client',
            xiti_xtsite: '388889',
            environnement: env
        };
    </script>

    <script async type="text/javascript" src="//cdn.tagcommander.com/2623/tc_LaBanquePostale_4.js"></script>
    <!-- TAG COMMANDER END //-->


<!-- default favicon -->
<link rel="shortcut icon" href="assets/logo-lbp.png" type="image/x-icon"/>
<link rel="icon" href="assets/logo-lbp.png" sizes="32x32" type="image/png"/>

<!-- for android mobile devices -->
<link rel="icon" href="assets/logo-lbp.png" type="image/png" sizes="192x192"/>

<!-- for apple mobile devices -->
<link rel="apple-touch-icon" href="assets/apple-touch-icon.png" type="image/png" sizes="152x152"/>
<link rel="apple-touch-icon" href="assets/apple-touch-icon.png" type="image/png" sizes="120x120"/>
<link rel="apple-touch-icon-precomposed" href="assets/apple-touch-icon.png" type="image/png" sizes="152x152"/>
<link rel="apple-touch-icon-precomposed" href="assets/apple-touch-icon.png" type="image/png" sizes="120x120"/>
<!-- google tv favicon -->
<link rel="icon" href="assets/logo-lbp.png" sizes="96x96" type="image/png"/>








<title>Connexion à l&#39;espace client - La Banque Postale</title>

<meta name="description" content="Connectez-vous à l&#39;espace sécurisé de La Banque Postale pour la clientèle des particuliers."/></head>
    
    <body data-title="Connexion à l&#39;espace client">
        

<div class="js-avoidlinks">
    <ul class="m-list--horizontal--align-left">
        <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="https://voscomptesenligne.labanquepostale.fr/voscomptes/canalXHTML/identif.ea?origin=particuliers"><span>Accès à vos comptes par l&#39;écran de connexion pleine page</span></a></li>
        <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-menu"><span>Accéder au Menu Principal</span></a></li>
        <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-contenu"><span>Accéder au Contenu éditorial</span></a></li>
        <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-footer"><span>Accéder au Pied de page</span></a></li>
    </ul>
</div>











<header id="header" class="o-header  " role="banner" data-percent="0">

    

<div class="m-logo u-spacing-s-xs">
    
        <a href="/" class="js-logo-type" title="Accueil La Banque Postale">
            
            <img src="assets/LOGO-LBP-digital-fd-clair-RVB.svg" width="50" height="50" alt="La Banque Postale"/>
            
        </a>
    
</div>


    <div class="o-header__wrapper">

        

<div class="o-metanavigation u-flex u-flex--column u-flex--horizontal u-spacing-md-left u-spacing-2xs-xs-left" aria-expanded="false">
    
    
    
    

    <button class="o-metanavigation__trigger" data-sticky-hidden title="Changer de site Particuliers - Afficher la liste des sites La Banque Postale">
        <span class="a-text--tiny">Changer de site </span>
        <span class="a-text--small lato-bold u-text-color--black">
            Particuliers 
            <svg viewBox="0 0 10 10" class="a-icon--s" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-down"></use>
            </svg>
        </span>
    </button>
    <div class="o-metanavigation__panel" role="dialog" aria-label="Changer de site" aria-modal="true">
        <div role="document">
            <div class="o-metanavigation__header u-flex u-flex--vertical">
                <p>
                    <span class="o-metanavigation__trigger" data-sticky-hidden>
                        <span class="a-text--tiny">Changer de site </span>
                        <span class="a-text--small lato-bold u-text-color--black">
                            Particuliers  
                            <svg viewBox="0 0 10 10" class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-up"></use>
                            </svg>
                        </span>
                    </span>
                </p>
                <button class="o-metanavigation__close">
                    <span class="sr-only">Fermer la liste des sites la Banque Postale</span>
                    <svg class="a-icon--s u-svg-color--grey_color_5" aria-hidden="true" focusable="false">
                        <use xlink:href="assets/svg-icons.svg#ic-interface-close"></use>
                    </svg>
                </button>
            </div>
            <ul class="o-metanavigation__boxlist u-flex--wrap">
                
                
                    
                    

                    <li class="m-metanavigation__box a-navigation__list__item u-bg-color--blue active">
                        
                        <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Particuliers
                        </span>
                        <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left" aria-expanded="false">
                            Particuliers
                        </button>
                        <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                        <div class="m-header__panel--mobile u-align-center">
                            <div class="m-header__panel__title hidden-md hidden-lg u-bg-color--blue">
                                <div class="m-metanavigation__box__title">
                                    
                                    <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                    <span class="u-text-color--white m-title--h5 u-text-color--black u-spacing-s-left ">Particuliers</span>
                                </div>
                            </div>
                            <ul class="m-metanavigation__box__list">
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/" class="m-metanavigation__box__link ">Accueil site Particuliers</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/particulier/solutions-jeunes.html" class="m-metanavigation__box__link ">Solutions Jeunes</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/particulier/solutions-famille.html" class="m-metanavigation__box__link ">Solutions Familles</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/particulier/solutions-retraites.html" class="m-metanavigation__box__link ">Solutions Retraités</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/particulier/solutions-patrimoniales.html" class="m-metanavigation__box__link ">Solutions Patrimoniales</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            </ul>
                        </div>
                        
                    </li>
                
                    
                    

                    <li class="m-metanavigation__box a-navigation__list__item ">
                        
                        <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Professionnels
                        </span>
                        <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left" aria-expanded="false">
                            Professionnels
                        </button>
                        <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                        <div class="m-header__panel--mobile u-align-center">
                            <div class="m-header__panel__title hidden-md hidden-lg ">
                                <div class="m-metanavigation__box__title">
                                    
                                    <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                    <span class=" m-title--h5 u-text-color--black u-spacing-s-left ">Professionnels</span>
                                </div>
                            </div>
                            <ul class="m-metanavigation__box__list">
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/professionnels.html" class="m-metanavigation__box__link ">Accueil site Professionnels</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/professionnels/developpement/commercants.html" class="m-metanavigation__box__link ">Artisans &amp; commerçants</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/professionnels/developpement/franchises.html" class="m-metanavigation__box__link ">Franchisés</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/professionnels/developpement/professions-liberales.html" class="m-metanavigation__box__link ">Professions libérales</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/professionnels/developpement/espace-createur.html" class="m-metanavigation__box__link ">Espace créateur</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/professionnels/developpement/auto-entrepreneurs.html" class="m-metanavigation__box__link ">Auto-entrepreneurs</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            </ul>
                        </div>
                        
                    </li>
                
                    
                    

                    <li class="m-metanavigation__box a-navigation__list__item ">
                        
                        <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Entreprises
                        </span>
                        <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left" aria-expanded="false">
                            Entreprises
                        </button>
                        <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                        <div class="m-header__panel--mobile u-align-center">
                            <div class="m-header__panel__title hidden-md hidden-lg ">
                                <div class="m-metanavigation__box__title">
                                    
                                    <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                    <span class=" m-title--h5 u-text-color--black u-spacing-s-left ">Entreprises</span>
                                </div>
                            </div>
                            <ul class="m-metanavigation__box__list">
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/entreprises.html" class="m-metanavigation__box__link ">Accueil site Entreprises</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            </ul>
                        </div>
                        
                    </li>
                
                    
                    

                    <li class="m-metanavigation__box a-navigation__list__item ">
                        
                        <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Associations
                        </span>
                        <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left" aria-expanded="false">
                            Associations
                        </button>
                        <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                        <div class="m-header__panel--mobile u-align-center">
                            <div class="m-header__panel__title hidden-md hidden-lg ">
                                <div class="m-metanavigation__box__title">
                                    
                                    <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                    <span class=" m-title--h5 u-text-color--black u-spacing-s-left ">Associations</span>
                                </div>
                            </div>
                            <ul class="m-metanavigation__box__list">
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/associations.html" class="m-metanavigation__box__link ">Accueil site Associations</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            </ul>
                        </div>
                        
                    </li>
                
                    
                    

                    <li class="m-metanavigation__box a-navigation__list__item ">
                        
                        <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Secteur public local
                        </span>
                        <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left" aria-expanded="false">
                            Secteur public local
                        </button>
                        <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                        <div class="m-header__panel--mobile u-align-center">
                            <div class="m-header__panel__title hidden-md hidden-lg ">
                                <div class="m-metanavigation__box__title">
                                    
                                    <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                    <span class=" m-title--h5 u-text-color--black u-spacing-s-left ">Secteur public local</span>
                                </div>
                            </div>
                            <ul class="m-metanavigation__box__list">
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/collectivites.html" class="m-metanavigation__box__link ">Accueil site Collectivités Locales</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/bailleurs-sociaux.html" class="m-metanavigation__box__link ">Accueil site Logement Social et Économie Mixte</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.fr/hopitaux.html" class="m-metanavigation__box__link ">Accueil site Hôpitaux et médico-social</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            </ul>
                        </div>
                        
                    </li>
                
                    
                    

                    <li class="m-metanavigation__box a-navigation__list__item ">
                        
                        <span class="m-title--h5 hidden-xs hidden-sm lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left">
                            Groupe La Banque Postale
                        </span>
                        <button class="js-metanavigation__box__btn m-title--h5 hidden-md hidden-lg lato-bold u-align-center u-spacing-xs-bottom u-spacing-none-xs-bottom u-spacing-none-sm-bottom u-spacing-s-sm-left u-spacing-s-xs-left" aria-expanded="false">
                            Groupe La Banque Postale
                        </button>
                        <svg class="a-navigation__list__item__icon a-icon--s hidden-md hidden-lg" aria-hidden="true" focusable="false">
                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                        <div class="m-header__panel--mobile u-align-center">
                            <div class="m-header__panel__title hidden-md hidden-lg ">
                                <div class="m-metanavigation__box__title">
                                    
                                    <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" title="Retour au premier niveau de la liste des sites">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                                        </svg>
                                        <span class="sr-only">Retour au premier niveau de la liste des sites</span>
                                    </button>
                                    <span class=" m-title--h5 u-text-color--black u-spacing-s-left ">Groupe La Banque Postale</span>
                                </div>
                            </div>
                            <ul class="m-metanavigation__box__list">
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.com/" class="m-metanavigation__box__link ">Accueil site Groupe</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.com/newsroom-publications.html" class="m-metanavigation__box__link ">Journalistes</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.com/investisseurs.html" class="m-metanavigation__box__link ">Investisseurs</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            
                                
                                <li class="a-text--small a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-none-xs-bottom">
                                    <a href="https://www.labanquepostale.com/candidats.html" class="m-metanavigation__box__link ">Candidats</a>
                                    <svg class="a-icon--xs hidden-xs hidden-sm" aria-hidden="true" focusable="false">
                                        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
                                    </svg>
                                </li>
                            </ul>
                        </div>
                        
                    </li>
                
            </ul>
        </div>
    </div>
</div>

        
        <div class="o-header__itemwrapper ">
            


<div class="m-searchbar">
    <button class="m-searchbar__opener" title="Ouvrir l&#39;outil de recherche">
        <svg viewBox="0 0 24 24" class="a-icon--s u-svg-color--grey_color_5" aria-hidden="true" focusable="false">
            <use xlink:href="assets/svg-icons.svg#ic-interface-search"></use>
        </svg>
        <span class="sr-only">Ouvrir l&#39;outil de recherche</span>
    </button>
    <button class="m-searchbar__close__wrapper">
        <span class="sr-only">Fermer la recherche</span>
        <svg class="a-icon--s m-searchbar__close u-svg-color--grey_color_5" aria-hidden="true" focusable="false">
            <use xlink:href="assets/svg-icons.svg#ic-interface-close"></use>
        </svg>
    </button>
    <div class="m-searchbar__autocomplete__wrapper hidden-sm hidden-md hidden-lg"></div>
</div>
<form class="m-searchbar__form" role="search">
    <div class="m-searchbar__form__overlay"></div>
    <label class="m-searchbar__label sr-only" for="searchTerm">Rechercher</label>
    <input type="search" placeholder="Saisissez votre recherche" data-lbp-search-input="/particulier/resultat-recherche-particulier.html" name="searchTerm" id="searchTerm" autocorrect="off" autocapitalize="off" spellcheck="false" autocomplete="off" class="m-searchbar__input"/>
    <button class="u-btn m-button--primary m-searchbar__submit" title="Rechercher sur labanquepostale.fr">
        <span class="m-button__icon a-icon--s">
            <svg viewBox="0 0 24 24" class="a-icon--s u-svg-color--white" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-search"></use>
            </svg>
        </span>
        <span class="sr-only-xs sr-only-sm">Rechercher</span>
    </button>
</form>
            <div class="m-header__links" data-client="true">
                







                





<a id="contact" href="/particulier/solutions-citoyennes.html" data-internal="false" title="Accéder à l&#39;espace solutions citoyennes" class="m-header__links__item m-header__links__item__white a-text--small  u-spacing-s-right u-spacing-s-left u-spcing-2xs-xs-right u-spcing-2xs-xs-left">
    
    <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
        <use xlink:href="assets/svg-icons.svg#ic-profile-citizen"></use>
    </svg>
    <span class="sr-only-xs">Solutions citoyennes</span>
    
</a>

                





<a id="client" href="/particulier/comptes-et-cartes/ouvrir-un-compte.html" data-internal="false" title="Ouvrir un compte bancaire à La Banque Postale" class="m-header__links__item m-header__links__item__blue a-text--small  u-spacing-s-right u-spacing-s-left u-spcing-2xs-xs-right u-spcing-2xs-xs-left">
    
    <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
        <use xlink:href="assets/svg-icons.svg#ic-products-beneficiary"></use>
    </svg>
    <span class="sr-only-xs">J'ouvre un compte</span>
    <svg class="a-icon--xs hidden-sm hidden-md hidden-lg" aria-hidden="true" focusable="false">
        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
    </svg>
</a>

                

                


<a href="/particulier/connexion-espace-client.html" id="connect" class="m-header__links__item m-header__links__item__connect m-header__links__item__blue a-text--small" data-connected-label="Connecté" data-connected-acces-label="Accéder à mon compte sécurisé" data-connected-url="https://voscomptesenligne.labanquepostale.fr/voscomptes/canalXHTML/identif.ea?origin=particuliers" title="Me connecter à mon compte sécurisé">

    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" class="a-icon--s">
        <use xlink:href="assets/svg-icons.svg#ic-safety-locker-unlocked"></use>
    </svg>
    <span class="sr-only-sm">Me connecter</span>
</a>


            </div>
            

<div class="m-header__menu" id="headermenu">
    <div class="headermenuline__wrapper"><span id="menu-h-line" class="animation-line"></span></div>
    <a id="avoid-menu" tabindex="-1"></a>
    <button class="m-header__menu__hamburger a-hamburger a-hamburger--slider" type="button" role="button" title="Ouvrir le menu" tabindex="0" data-close-title="Fermer le menu" data-open-title="Ouvrir le menu">
        <span class="m-header__menu__hamburger__label sr-only">Ouvrir le menu</span>
        <span class="a-hamburger__box">
            <span class="a-hamburger__inner" aria-hidden="true"></span>
        </span>
    </button>
    <nav role="navigation" aria-label="Menu principal">
        <ul class="m-header__menu__list m-header__panel--mobile u-spacing-none-xs u-spacing-none-sm u-spacing-s-top u-spacing-s-bottom">
            <li class="visible-xs-block">





<a id="client" href="/particulier/comptes-et-cartes/ouvrir-un-compte.html" data-internal="false" title="Ouvrir un compte bancaire à La Banque Postale" class="m-header__links__item m-header__links__item__blue a-text--small  u-spacing-s-right u-spacing-s-left u-spcing-2xs-xs-right u-spcing-2xs-xs-left">
    
    <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
        <use xlink:href="assets/svg-icons.svg#ic-products-beneficiary"></use>
    </svg>
    <span class="sr-only-xs">J'ouvre un compte</span>
    <svg class="a-icon--xs hidden-sm hidden-md hidden-lg" aria-hidden="true" focusable="false">
        <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
    </svg>
</a>
</li>
            
    
        <li class="a-navigation__list__item a-navigation__menu__item u-margin-none-xs u-margin-none-sm u-spacing-s-sm" menu-index="0" data-level="1">
            
            <button role="button" class="a-navigation__menu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Comptes et cartes</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <span class="line--wrapper--vertical"></span>
            <div class="m-header__submenu m-header__panel--mobile">
                <div class="m-header__submenu__wrapper">
                    <div class="m-header__submenu__title m-header__panel__title u-margin-2xl-left u-margin-none-xs u-margin-none-sm u-spacing-lg-bottom">
                        <div>
                            <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" data-level="2">
                                <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                    <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                                </svg>
                                <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu principal</span>
                            </button>
                            <p class="a-text--small lato-bold u-text-color--black">Comptes et cartes</p>
                        </div>
                        <p class="a-text--small hidden-sm hidden-xs">Ouvrez un compte bancaire à La Banque Postale et bénéficiez de nos différentes offres et services banque et assurance. </p>
                    </div>
                    <div class="m-header__submenu__list__wrapper   u-spacing-2xl-left u-spacing-none-sm u-spacing-none-xs">
                        <span class="submenu-v-line animation-line"></span>
                        <ul class="m-header__submenu__list u-margin-2xl-right u-margin-none-sm u-margin-none-xs" id="submenu-0">
                            
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Compte bancaire</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Compte bancaire</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/comptes-bancaires/formule-de-compte.html" class="a-text--small js-tracking-item">Formule de Compte</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/comptes-bancaires/formule-de-compte-simplicite.html" class="a-text--small js-tracking-item">Formule de Compte Simplicité</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/comptes-bancaires/mobilite-bancaire.html" class="a-text--small js-tracking-item">Mobilité bancaire</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/comptes-bancaires/assurances.html" class="a-text--small js-tracking-item">Assurances au quotidien</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/comptes-bancaires/decouvert-autorise.html" class="a-text--small js-tracking-item">Découvert autorisé</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/comptes-bancaires/ouverture-de-compte-jeune.html" class="a-text--small js-tracking-item">Ouvrir un compte spécial jeune</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/comptes-bancaires/ouverture-de-compte-mineur.html" class="a-text--small js-tracking-item">Ouvrir un compte 12-17 ans</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Cartes bancaires</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Cartes bancaires</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-realys.html" class="a-text--small js-tracking-item">Carte Réalys</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-visa-classic.html" class="a-text--small js-tracking-item">Carte Visa Classic</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-visa-premier.html" class="a-text--small js-tracking-item">Carte Visa Premier</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-visa-platinum.html" class="a-text--small js-tracking-item">Carte Visa Platinum</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-visa-infinite.html" class="a-text--small js-tracking-item">Carte Visa Infinite</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-prepayee-de-la-banque-postale.html" class="a-text--small js-tracking-item">Carte Prépayée de La Banque Postale</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-protectys.html" class="a-text--small js-tracking-item">Carte Protectys</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/cartes-bancaires/carte-regliss.html" class="a-text--small js-tracking-item">Carte Regliss</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Services cartes</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Services cartes</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/services-de-cartes/carte-option-credit.html" class="a-text--small js-tracking-item">Carte Option Crédit</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/services-de-cartes/cartes-caritatives.html" class="a-text--small js-tracking-item">Cartes caritatives</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/services-de-cartes/service-debit-differe.html" class="a-text--small js-tracking-item">Service Débit Différé</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/services-de-cartes/service-e-carte-bleue.html" class="a-text--small js-tracking-item">e-Carte Bleue</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/services-de-cartes/3d-secure.html" class="a-text--small js-tracking-item">3D Secure</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/services-de-cartes/paiement-sans-contact.html" class="a-text--small js-tracking-item">Paiement sans contact</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/services-de-cartes/apple-pay.html" class="a-text--small js-tracking-item">Apple Pay</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/services-de-cartes/samsung-pay.html" class="a-text--small js-tracking-item">Samsung Pay</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Moyens de paiement</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Moyens de paiement</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/virement-sepa.html" class="a-text--small js-tracking-item">Virement Sepa</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/virement-international.html" class="a-text--small js-tracking-item">Virement international</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/virement-sepa-instantane.html" class="a-text--small js-tracking-item">Virement SEPA instantané</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/prelevement.html" class="a-text--small js-tracking-item">Le Prélèvement SEPA</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/cheques.html" class="a-text--small js-tracking-item">Le Chèque</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/paylib-entre-amis.html" class="a-text--small js-tracking-item">Paylib entre amis</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/moyens-de-paiement/service-western-union.html" class="a-text--small js-tracking-item">Service Western Union</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Services digitaux</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Services digitaux</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/espaces-clients/banque-en-ligne.html" class="a-text--small js-tracking-item">Espace Client Internet</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/espaces-clients/application-mobile.html" class="a-text--small js-tracking-item">Application mobile</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/espaces-clients/cartes-prepayees.html" class="a-text--small js-tracking-item">Espaces clients Cartes Prépayées</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/espaces-clients/securite.html" class="a-text--small js-tracking-item">Sécurité</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/espaces-clients/e-releve.html" class="a-text--small js-tracking-item">E-relevé</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/espaces-clients/messagerie-securisee.html" class="a-text--small js-tracking-item">Messagerie Sécurisée</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/espaces-clients/la-banque-postale-chez-soi.html" class="a-text--small js-tracking-item">La Banque Postale Chez Soi</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/comptes-et-cartes/espaces-clients/actualisation-des-informations-personnelles.html" class="a-text--small js-tracking-item">Actualisation des informations personnelles</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            <a href="/particulier/comptes-et-cartes/ouvrir-un-compte.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Ouvrir un compte bancaire </a>
            
            
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Ouvrir un compte bancaire </p>
                    </div>
                </div>
                
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2" last-item>
            <span class="submenu-h-line animation-line"></span>
            <a href="/particulier/comptes-et-cartes/ma-french-bank.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Ma French Bank</a>
            
            
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Comptes et cartes</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Ma French Bank</p>
                    </div>
                </div>
                
            </div>
        </li>
    

                        </ul>
                    </div>
                    
                    <div class="m-header__submenu__push">
                        <div class="m-header__submenu__push__wrapper">
                            
                            <div>


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="title aem-GridColumn aem-GridColumn--default--12">





<div data-back-content="Retour au contenu" class="m-title u-spacing-s-bottom u-text-color--blue  u-color--blue u-align-center">
    
    
    <h3>Le Mag</h3>
</div>




</div>
<div class="a-text aem-GridColumn aem-GridColumn--default--12">
<article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
    
    <p style="text-align: center;">Actualités, conseils, solutions... Découvrez tous nos articles banque et assurance et les réponses aux questions que vous vous posez autour de l'argent et de la vie quotidienne. </p>

</article>


</div>
<div class="button aem-GridColumn aem-GridColumn--default--12">










<div class="m-button u-align-center u-spacing-2xl-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
    <a href="https://www.labanquepostale.fr/particulier/accompagner/actualites-et-conseils.html?at_medium=customS6&amp;at_campaign=anim_edito_accompagner&amp;at_custom1=espace_public&amp;at_custom2=fil_actu_accompagner&amp;at_custom3=menu_comptes_cartes" class="u-btn m-button--content m-button--primary" data-internal="false" js-btn-tracking>
        
        
        
        <span>
            Découvrir le Mag
            
        </span>
        
        
    </a>
</div>

</div>
<div class="image aem-GridColumn aem-GridColumn--default--12">





<div class=" u-spacing-2xl-bottom m-image">
    
    

    
    
    
    

    
        
            <picture>
                
                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-couple-smartphone.jpg-rend-cq5dam.web.375.375.jpg , /content/dam/lbp/images/homepage/LBP-couple-smartphone.jpg-rend-cq5dam.web.750.750.jpg 2x"/>
                
                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-couple-smartphone.jpg-rend-cq5dam.web.375.375.jpg , /content/dam/lbp/images/homepage/LBP-couple-smartphone.jpg-rend-cq5dam.web.750.750.jpg 2x"/>
                
                
                
                <img src="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/LBP-couple-smartphone.jpg-rend-cq5dam.web.750.750.jpg" width="750px" height="534px" class="  a-image--responsive" alt="" loading="lazy"/>
                
            </picture>
            
            
        
        
        
    

</div></div>

    
</div>
</div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
    
        <li class="a-navigation__list__item a-navigation__menu__item u-margin-none-xs u-margin-none-sm u-spacing-s-sm" menu-index="0" data-level="1">
            
            <button role="button" class="a-navigation__menu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Epargner</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <span class="line--wrapper--vertical"></span>
            <div class="m-header__submenu m-header__panel--mobile">
                <div class="m-header__submenu__wrapper">
                    <div class="m-header__submenu__title m-header__panel__title u-margin-2xl-left u-margin-none-xs u-margin-none-sm u-spacing-lg-bottom">
                        <div>
                            <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" data-level="2">
                                <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                    <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                                </svg>
                                <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu principal</span>
                            </button>
                            <p class="a-text--small lato-bold u-text-color--black">Epargner</p>
                        </div>
                        <p class="a-text--small hidden-sm hidden-xs">Découvrez toutes les solutions de livrets d'épargne à taux attractifs et placements financier (ISR, bourse, PEA…) de La Banque Postale, adaptés à vos besoins.</p>
                    </div>
                    <div class="m-header__submenu__list__wrapper   u-spacing-2xl-left u-spacing-none-sm u-spacing-none-xs">
                        <span class="submenu-v-line animation-line"></span>
                        <ul class="m-header__submenu__list u-margin-2xl-right u-margin-none-sm u-margin-none-xs" id="submenu-0">
                            
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Livrets d'épargne</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Livrets d'épargne</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/livret-epargne/livret-a.html" class="a-text--small js-tracking-item">Livret A</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/livret-epargne/ldds.html" class="a-text--small js-tracking-item">Livret de développement durable et solidaire (LDDS)</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/livret-epargne/lep.html" class="a-text--small js-tracking-item">Livret d'épargne populaire</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/livret-epargne/livret-jeune.html" class="a-text--small js-tracking-item">Livret jeune Swing</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/livret-epargne/compte-sur-livret.html" class="a-text--small js-tracking-item">Compte sur livret</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/livret-epargne/simulateur-de-livret.html" class="a-text--small js-tracking-item">Simulateur livrets d'épargne</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/livret-epargne/tous-les-livrets.html" class="a-text--small js-tracking-item">Tous les livrets</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Epargne logement</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Epargne logement</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/epargne-logement/plan-epargne-logement.html" class="a-text--small js-tracking-item">Plan épargne logement</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/epargne-logement/compte-epargne-logement.html" class="a-text--small js-tracking-item">Compte épargne logement</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Compte à terme</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Compte à terme</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/compte-a-terme/toniciel-croissance.html" class="a-text--small js-tracking-item">Toniciel Croissance</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/compte-a-terme/toniciel-sequence.html" class="a-text--small js-tracking-item">Toniciel Séquence</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurance vie</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Assurance vie</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/vivaccio.html" class="a-text--small js-tracking-item">Vivaccio</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/cachemire-2.html" class="a-text--small js-tracking-item">Cachemire 2</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/cachemire-pat.html" class="a-text--small js-tracking-item">Cachemire Patrimoine</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/perspective-capi.html" class="a-text--small js-tracking-item">Perspective Capi</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/cachemire-per.html" class="a-text--small js-tracking-item">Cachemire PER</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/assurance-vie-et-solution-retraite/pacte-generation.html" class="a-text--small js-tracking-item">Pacte Génération</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Placements financiers</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Placements financiers</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/placements-financiers/diversification-cle-en-main.html" class="a-text--small js-tracking-item">La diversification clé en main</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/placements-financiers/investissement-avec-protection-du-capital.html" class="a-text--small js-tracking-item">Investissement avec protection du capital </a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/placements-financiers/placement-immobilier.html" class="a-text--small js-tracking-item">Les placements dans l'immobilier</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/placements-financiers/investissement-socialement-responsable-isr.html" class="a-text--small js-tracking-item">Investissement responsable et solidaire</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/placements-financiers/opc-autonomie.html" class="a-text--small js-tracking-item">Les OPC en toute autonomie</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/placements-financiers/solutions-investissement-diminution-impot.html" class="a-text--small js-tracking-item">Solutions pour investir tout en diminuant ses impôts</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/placements-financiers/cto.html" class="a-text--small js-tracking-item">Compte-Titres ordinaire</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/placements-financiers/en-savoir-plus.html" class="a-text--small js-tracking-item">En savoir plus</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Univers PEA et PEA PME-ETI</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Univers PEA et PEA PME-ETI</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/pea-et-pea-pme-eti/newsletter-reperes.html" class="a-text--small js-tracking-item">Newsletter Repères</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/pea-et-pea-pme-eti/selection-de-fonds-gestion-pea.html" class="a-text--small js-tracking-item">Sélection pour gérer votre PEA</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/pea-et-pea-pme-eti/offre-cle-en-main-pour-debuter-en-bourse.html" class="a-text--small js-tracking-item">Offre clé en main pour débuter en bourse</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/pea-et-pea-pme-eti/services-associes-au-pea.html" class="a-text--small js-tracking-item">Services associés au PEA</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/pea-et-pea-pme-eti/gestion-sous-mandat-pea.html" class="a-text--small js-tracking-item">Gestion sous mandat en PEA</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/pea-et-pea-pme-eti/investissement-dans-le-tissus-economique-des-pme-eti.html" class="a-text--small js-tracking-item">Investissement dans le tissu économique des PME-ETI</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/pea-et-pea-pme-eti/bourse-en-ligne.html" class="a-text--small js-tracking-item">Bourse en ligne</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/pea-et-pea-pme-eti/fiscalite-du-pea-et-du-pea-pme-eti.html" class="a-text--small js-tracking-item">Fiscalité du PEA et du PEA PME-ETI</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Services épargne</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Services épargne</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/services-epargne/services-interets-solidaires.html" class="a-text--small js-tracking-item">Services Intérêts Solidaires</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/services-epargne/versements-programmes-regulys.html" class="a-text--small js-tracking-item">Versements programmes Regulys</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/services-epargne/versements-programmes-ccepargne.html" class="a-text--small js-tracking-item">Versements programmes CcéPargne</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Simulateurs épargne</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Simulateurs épargne</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/simulateurs-epargne/diagnostic-retraite.html" class="a-text--small js-tracking-item">Simulation retraite</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/simulateurs-epargne/diagnostic-succession.html" class="a-text--small js-tracking-item">Simulateur succession</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/simulateurs-epargne/simulateur-impots-sur-le-revenu.html" class="a-text--small js-tracking-item">Simulateur impôt sur le revenu</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/simulateurs-epargne/simulateur-impts-sur-la-fortune.html" class="a-text--small js-tracking-item">Simulateur impôt sur la fortune immobilière (IFI)</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/epargner/simulateurs-epargne/simulateur-livret.html" class="a-text--small js-tracking-item">Simulateur livret</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2" last-item>
            <span class="submenu-h-line animation-line"></span>
            <a href="/particulier/epargner/petra.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Perspective Transmission</a>
            
            
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Epargner</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Perspective Transmission</p>
                    </div>
                </div>
                
            </div>
        </li>
    

                        </ul>
                    </div>
                    
                    <div class="m-header__submenu__push">
                        <div class="m-header__submenu__push__wrapper">
                            
                            <div>


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="title aem-GridColumn aem-GridColumn--default--12">





<div data-back-content="Retour au contenu" class="m-title u-spacing-s-bottom u-text-color--blue  u-color--blue u-align-center">
    
    
    <h3>Développez votre patrimoine : cap sur la diversification</h3>
</div>




</div>
<div class="a-text aem-GridColumn aem-GridColumn--default--12">
<article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
    
    <p style="text-align: center;">Pour développer et espérer faire prospérer votre patrimoine, l’heure de la diversification a sonné.</p>

</article>


</div>
<div class="button aem-GridColumn aem-GridColumn--default--12">










<div class="m-button u-align-center u-spacing-2xl-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
    <a href="https://www.labanquepostale.fr/particulier/accompagner/avenir/developpement-du-patrimoine.html?at_medium=customS6&amp;at_campaign=anim_edito_accompagner&amp;at_custom1=espace_public&amp;at_custom2=dossier_dvper_patrimoine_diversification&amp;at_custom3=menu_epargner" class="u-btn m-button--content m-button--primary" data-internal="false" js-btn-tracking>
        
        
        
        <span>
            Découvrir nos conseils
            
        </span>
        
        
    </a>
</div>

</div>
<div class="image aem-GridColumn aem-GridColumn--default--12">





<div class=" u-spacing-2xl-bottom m-image">
    
    

    
    
    
    

    
        
            <picture>
                
                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/lbp-investissements-home.jpg-rend-cq5dam.web.375.375.jpg , /content/dam/lbp/images/homepage/lbp-investissements-home.jpg-rend-cq5dam.web.750.750.jpg 2x"/>
                
                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/lbp-investissements-home.jpg-rend-cq5dam.web.375.375.jpg , /content/dam/lbp/images/homepage/lbp-investissements-home.jpg-rend-cq5dam.web.750.750.jpg 2x"/>
                
                
                
                <img src="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/lbp-investissements-home.jpg-rend-cq5dam.web.750.750.jpg" width="750px" height="533px" class="  a-image--responsive" alt="" loading="lazy"/>
                
            </picture>
            
            
        
        
        
    

</div></div>

    
</div>
</div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
    
        <li class="a-navigation__list__item a-navigation__menu__item u-margin-none-xs u-margin-none-sm u-spacing-s-sm" menu-index="0" data-level="1">
            
            <button role="button" class="a-navigation__menu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Emprunter</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <span class="line--wrapper--vertical"></span>
            <div class="m-header__submenu m-header__panel--mobile">
                <div class="m-header__submenu__wrapper">
                    <div class="m-header__submenu__title m-header__panel__title u-margin-2xl-left u-margin-none-xs u-margin-none-sm u-spacing-lg-bottom">
                        <div>
                            <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" data-level="2">
                                <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                    <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                                </svg>
                                <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu principal</span>
                            </button>
                            <p class="a-text--small lato-bold u-text-color--black">Emprunter</p>
                        </div>
                        <p class="a-text--small hidden-sm hidden-xs">Financez vos projets grâce à nos solutions de prêts immobilier et crédits à la consommation. Comparez nos crédits et réalisez une simulation en ligne.</p>
                    </div>
                    <div class="m-header__submenu__list__wrapper   u-spacing-2xl-left u-spacing-none-sm u-spacing-none-xs">
                        <span class="submenu-v-line animation-line"></span>
                        <ul class="m-header__submenu__list u-margin-2xl-right u-margin-none-sm u-margin-none-xs" id="submenu-0">
                            
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Financer mon logement et mes travaux</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Financer mon logement et mes travaux</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-habitat-taux-fixe.html" class="a-text--small js-tracking-item">Prêt habitat à taux fixe </a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-personnel-travaux.html" class="a-text--small js-tracking-item">Prêt personnel Travaux</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-a-taux-zero-ptz.html" class="a-text--small js-tracking-item">Prêt à Taux Zéro</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-logement-et-travaux/eco-pret-a-taux-zero.html" class="a-text--small js-tracking-item">Eco Prêt à Taux Zéro</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-relais.html" class="a-text--small js-tracking-item">Prêt relais</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-conventionne.html" class="a-text--small js-tracking-item">Prêt Conventionné</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-logement-et-travaux/pret-accession-sociale.html" class="a-text--small js-tracking-item">Prêt accession sociale</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-logement-et-travaux/guide-immobilier.html" class="a-text--small js-tracking-item">Guide de l'immobilier : achat, travaux, locatif...</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-logement-et-travaux/toutes-nos-solutions.html" class="a-text--small js-tracking-item">Toutes nos solutions</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Financement de projets</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Financement de projets</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-de-projets/pret-personnel-projet.html" class="a-text--small js-tracking-item">Prêt personnel projet</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-de-projets/credit-renouvelable.html" class="a-text--small js-tracking-item">Crédit Renouvelable</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-de-projets/financement-participatif.html" class="a-text--small js-tracking-item">Financement participatif</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-de-projets/toutes-nos-solutions.html" class="a-text--small js-tracking-item">Toutes nos solutions</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            <a href="/particulier/emprunter/financement-vehicule-pret-personnel-auto.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Financement véhicule</a>
            
            
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Financement véhicule</p>
                    </div>
                </div>
                
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Financements à destination des jeunes</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Financements à destination des jeunes</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-a-destination-des-jeunes/pret-personnel-etudiant.html" class="a-text--small js-tracking-item">Prêt personnel Étudiant</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-a-destination-des-jeunes/pret-personnel-apprenti.html" class="a-text--small js-tracking-item">Prêt personnel Apprenti </a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-a-destination-des-jeunes/financement-du-permis-de-conduire.html" class="a-text--small js-tracking-item">Prêt Permis à 1€ par jour</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/financement-a-destination-des-jeunes/toutes-nos-solutions.html" class="a-text--small js-tracking-item">Toutes nos solutions</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Gestion de budget</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Gestion de budget</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/gestion-de-budgets/rachat-de-credit-consommation.html" class="a-text--small js-tracking-item">Rachat de crédits</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/gestion-de-budgets/credit-renouvelable.html" class="a-text--small js-tracking-item">Crédit renouvelable</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/gestion-de-budgets/rachat-credit-immobilier.html" class="a-text--small js-tracking-item">Rachat de crédit immobilier</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/gestion-de-budgets/toutes-nos-solutions.html" class="a-text--small js-tracking-item">Toutes nos solutions</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurance de financement</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Assurance de financement</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/assurance-de-financement/assurance-emprunteur.html" class="a-text--small js-tracking-item">Assurance emprunteur </a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/assurance-de-financement/assurance-perte-emploi.html" class="a-text--small js-tracking-item">Assurance perte d'emploi</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/assurance-de-financement/assurance-credit-conso.html" class="a-text--small js-tracking-item">Assurance crédit à la consommation </a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/assurance-de-financement/convention-AERAS.html" class="a-text--small js-tracking-item">Convention AERAS</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2" last-item>
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Simulateurs projets</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Emprunter</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Simulateurs projets</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/simulateurs-projets/pret-personnel-global.html" class="a-text--small js-tracking-item">Simulateur crédit à la consommation</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/simulateurs-projets/pret-etudiant.html" class="a-text--small js-tracking-item">Simulateur Prêt étudiant</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/simulateurs-projets/calculette-immo.html" class="a-text--small js-tracking-item">Calculette Prêt immobilier</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/simulateurs-projets/credit-renouvelable.html" class="a-text--small js-tracking-item">Simulateur Crédit renouvelable</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/emprunter/simulateurs-projets/rachat-de-credit.html" class="a-text--small js-tracking-item">Simulateur Regroupement de crédits</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    

                        </ul>
                    </div>
                    
                    <div class="m-header__submenu__push">
                        <div class="m-header__submenu__push__wrapper">
                            
                            <div>
    <div class="row title">
        
            <div class="title col-xs-12 col-sm-offset-1 col-sm-10">





<div data-back-content="Retour au contenu" class="m-title u-spacing-s-bottom u-text-color--blue color-override u-color--orange u-align-center">
    <svg viewBox="0 0 24 24" class="a-icon--m u-spacing-3xs-right" aria-hidden="true" focusable="false">
        <use xlink:href="assets/svg-icons.svg#ic-products-domains-estateloan"></use>
    </svg>
    
    <h3>Prêt immobilier</h3>
</div>




</div>

        
    </div>
<div class="row text">
        
            <div class="a-text col-xs-12 col-sm-offset-1 col-sm-10">
<article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
    
    <p style="text-align: center;">Vous souhaitez devenir propriétaire ? Financez votre projet immobilier en quelques clics !</p>

</article>


</div>

        
    </div>
<div class="row button">
        
            <div class="button col-xs-12 col-sm-offset-1 col-sm-10">










<div class="m-button u-align-center u-spacing-2xs-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
    <a href="https://cionline.labanquepostale.fr/szb/lbp" class="u-btn m-button--content m-button--primary" data-internal="false" js-btn-tracking>
        
        
        
        <span>
            Demander un prêt immobilier
            
        </span>
        
        
    </a>
</div>

</div>

        
    </div>
<div class="row image">
        
            <div class="image col-xs-12 col-sm-12">





<div class=" u-spacing-2xl-bottom m-image">
    
    

    
    
    
    

    
        
            <picture>
                
                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/home-couple-logement-immo.jpg-rend-cq5dam.web.1080.1080.jpg , /content/dam/lbp/images/homepage/home-couple-logement-immo.jpg-rend-cq5dam.web.3000.3000.jpg 2x"/>
                
                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/home-couple-logement-immo.jpg-rend-cq5dam.web.375.375.jpg , /content/dam/lbp/images/homepage/home-couple-logement-immo.jpg-rend-cq5dam.web.750.750.jpg 2x"/>
                
                
                
                <img src="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/home-couple-logement-immo.jpg-rend-cq5dam.web.3000.3000.jpg" width="3000px" height="533px" class="  a-image--responsive" alt="" loading="lazy"/>
                
            </picture>
            
            
        
        
        
    

</div></div>

        
    </div>

    
</div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
    
        <li class="a-navigation__list__item a-navigation__menu__item u-margin-none-xs u-margin-none-sm u-spacing-s-sm" menu-index="0" data-level="1">
            
            <button role="button" class="a-navigation__menu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurer</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <span class="line--wrapper--vertical"></span>
            <div class="m-header__submenu m-header__panel--mobile">
                <div class="m-header__submenu__wrapper">
                    <div class="m-header__submenu__title m-header__panel__title u-margin-2xl-left u-margin-none-xs u-margin-none-sm u-spacing-lg-bottom">
                        <div>
                            <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" data-level="2">
                                <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                    <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                                </svg>
                                <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu principal</span>
                            </button>
                            <p class="a-text--small lato-bold u-text-color--black">Assurer</p>
                        </div>
                        <p class="a-text--small hidden-sm hidden-xs">Comparez nos différentes assurances auto, habitation, santé, protection juridique, décès... La Banque Postale vous propose des formules adaptées pour vous protéger ainsi que vos proches.</p>
                    </div>
                    <div class="m-header__submenu__list__wrapper   u-spacing-2xl-left u-spacing-none-sm u-spacing-none-xs">
                        <span class="submenu-v-line animation-line"></span>
                        <ul class="m-header__submenu__list u-margin-2xl-right u-margin-none-sm u-margin-none-xs" id="submenu-0">
                            
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurances véhicules</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Assurer</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Assurances véhicules</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/assurances-vehicules/assurance-auto.html" class="a-text--small js-tracking-item">Assurance Auto</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/assurances-vehicules/assurance-2-roues.html" class="a-text--small js-tracking-item">Assurance 2 roues</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/assurances-vehicules/protection-juridique.html" class="a-text--small js-tracking-item">Protection Juridique</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurances logement</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Assurer</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Assurances logement</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/assurances-logement/assurance-habitation.html" class="a-text--small js-tracking-item">Assurance habitation</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/assurances-logement/assurance-habitation-special-jeunes.html" class="a-text--small js-tracking-item">Assurance habitation tarif Jeunes</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/assurances-logement/protection-juridique.html" class="a-text--small js-tracking-item">Protection Juridique</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            <a href="/particulier/assurer/assurances-sante.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Assurance Santé</a>
            
            
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Assurer</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Assurance Santé</p>
                    </div>
                </div>
                
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Protection de la famille</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Assurer</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Protection de la famille</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/protection-de-la-famille/assurance-accident-de-la-vie.html" class="a-text--small js-tracking-item">Assurance des Accidents de la vie</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/protection-de-la-famille/assurance-deces-invalidite.html" class="a-text--small js-tracking-item">Assurance décès et invalidité</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/protection-de-la-famille/assurance-obseque.html" class="a-text--small js-tracking-item">Assurance Solution Obsèques</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/protection-de-la-famille/assurance-coups-durs-sante.html" class="a-text--small js-tracking-item">Assurance Coups Durs Santé</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2" last-item>
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assurances au quotidien</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Assurer</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Assurances au quotidien</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/assurances-au-quotidien/protection-juridique.html" class="a-text--small js-tracking-item">Protection juridique</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/assurances-au-quotidien/assurance-moyens-de-paiement-allyatis.html" class="a-text--small js-tracking-item">Assurance Moyens de paiements</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/assurances-au-quotidien/assurance-appareils-nomades.html" class="a-text--small js-tracking-item">Assurance des Appareils nomades </a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/assurer/assurances-au-quotidien/assurance-extension-de-garantie.html" class="a-text--small js-tracking-item">Assurance Extension de garantie</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    

                        </ul>
                    </div>
                    
                    <div class="m-header__submenu__push">
                        <div class="m-header__submenu__push__wrapper">
                            
                            <div>


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="title aem-GridColumn aem-GridColumn--default--12">





<div data-back-content="Retour au contenu" class="m-title u-spacing-s-bottom  color-override u-color--green u-align-center">
    <svg viewBox="0 0 24 24" class="a-icon--m u-spacing-3xs-right" aria-hidden="true" focusable="false">
        <use xlink:href="assets/svg-icons.svg#ic-life-car"></use>
    </svg>
    
    <h4>Assurance Auto</h4>
</div>




</div>
<div class="a-text aem-GridColumn aem-GridColumn--default--12">
<article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
    
    <p style="text-align: center;"><span class="a-text--emphasis"><span class="u-text-color--blue">Profitez de 3 mois offerts</span></span><br />
pour toute nouvelle souscription du 01/04/2022 au 30/04/2022 inclus.</p>

</article>


</div>
<div class="button aem-GridColumn aem-GridColumn--default--12">










<div class="m-button u-align-center u-spacing-2xl-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
    <a href="https://assurances.labanquepostale.fr/apps/responsive/#/devis/auto" class="u-btn m-button--content m-button--primary" data-internal="false" js-btn-tracking>
        
        
        
        <span>
            Faire un devis en ligne
            
        </span>
        
        
    </a>
</div>

</div>
<div class="image aem-GridColumn aem-GridColumn--default--12">





<div class=" u-spacing-2xl-bottom m-image">
    
    

    
    
    
    

    
        
            <picture>
                
                
                
                <img class="  a-image--responsive" alt="" loading="lazy"/>
                
            </picture>
            
            
        
        
        
    

</div></div>
<div class="image aem-GridColumn aem-GridColumn--default--12">





<div class=" u-spacing-none-bottom m-image">
    
    

    
    
    
    

    
        
            <picture>
                
                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/home-assurance-auto-couple.jpg-rend-cq5dam.web.750.750.jpg , /content/dam/lbp/images/homepage/home-assurance-auto-couple.jpg-rend-cq5dam.web.1080.1080.jpg 2x"/>
                
                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/home-assurance-auto-couple.jpg-rend-cq5dam.web.375.375.jpg , /content/dam/lbp/images/homepage/home-assurance-auto-couple.jpg-rend-cq5dam.web.750.750.jpg 2x"/>
                
                
                
                <img src="https://www.labanquepostale.fr/content/dam/lbp/images/homepage/home-assurance-auto-couple.jpg-rend-cq5dam.web.1080.1080.jpg" width="1080px" height="533px" class="  a-image--responsive" alt="" loading="lazy"/>
                
            </picture>
            
            
        
        
        
    

</div></div>

    
</div>
</div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
    
        <li class="a-navigation__list__item a-navigation__menu__item u-margin-none-xs u-margin-none-sm u-spacing-s-sm" menu-index="0" data-level="1">
            
            <button role="button" class="a-navigation__menu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Conseils et actus</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <span class="line--wrapper--vertical"></span>
            <div class="m-header__submenu m-header__panel--mobile">
                <div class="m-header__submenu__wrapper">
                    <div class="m-header__submenu__title m-header__panel__title u-margin-2xl-left u-margin-none-xs u-margin-none-sm u-spacing-lg-bottom">
                        <div>
                            <button role="button" class="m-header__panel__back submenu hidden-md hidden-lg" data-level="2">
                                <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                    <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                                </svg>
                                <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu principal</span>
                            </button>
                            <p class="a-text--small lato-bold u-text-color--black">Conseils et actus</p>
                        </div>
                        <p class="a-text--small hidden-sm hidden-xs">La Banque Postale vous accompagne tout au long de la vie. Découvrez les conseils et idées pratiques qui pourraient vous intéresser.</p>
                    </div>
                    <div class="m-header__submenu__list__wrapper   u-spacing-2xl-left u-spacing-none-sm u-spacing-none-xs">
                        <span class="submenu-v-line animation-line"></span>
                        <ul class="m-header__submenu__list u-margin-2xl-right u-margin-none-sm u-margin-none-xs" id="submenu-0">
                            
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            <a href="/particulier/accompagner/actualites-et-conseils.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Le Mag</a>
            
            
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Conseils et actus</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Le Mag</p>
                    </div>
                </div>
                
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Investir dans l'immobilier</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Conseils et actus</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Investir dans l'immobilier</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/logement/premier-achat--immo.html" class="a-text--small js-tracking-item">Premier achat immobilier </a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/logement/renovation-et-travaux.html" class="a-text--small js-tracking-item">Je rénove ou je fais des travaux dans mon logement </a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/logement/achat-residence-secondaire.html" class="a-text--small js-tracking-item">Acheter ma résidence secondaire</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/logement/achat-avant-revente.html" class="a-text--small js-tracking-item">J’achète une nouvelle résidence principale avant d’avoir revendu l’actuelle </a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/logement/investissement-locatif.html" class="a-text--small js-tracking-item">Je souhaite investir dans le locatif </a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/logement/demande-de-financement.html" class="a-text--small js-tracking-item">Faire une demande de financement</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            <a href="/particulier/accompagner/voiture.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Acheter un véhicule</a>
            
            
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Conseils et actus</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Acheter un véhicule</p>
                    </div>
                </div>
                
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Préparer son avenir et sa retraite</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Conseils et actus</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Préparer son avenir et sa retraite</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/avenir/premiere-epargne.html" class="a-text--small js-tracking-item">Quatre pistes pour bien débuter votre vie d’épargnant</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/avenir/developpement-du-patrimoine.html" class="a-text--small js-tracking-item">Développer son patrimoine</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/avenir/strategie-patrimoniale-par-objectifs.html" class="a-text--small js-tracking-item">Adapter son patrimoine à ses priorités</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/avenir/retraite.html" class="a-text--small js-tracking-item">Préparer sa retraite : anticiper baisse de revenus</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Anticiper les coups durs</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Conseils et actus</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Anticiper les coups durs</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/soucis/perte-proche.html" class="a-text--small js-tracking-item">Perdre un proche</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/soucis/perte-emploi.html" class="a-text--small js-tracking-item">Surmonter la perte de son emploi</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/soucis/separation.html" class="a-text--small js-tracking-item">Gérer une séparation ou un divorce</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            <a href="/particulier/accompagner/assistance-a-un-majeur-protege.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">Accompagner une personne protégée</a>
            
            
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Conseils et actus</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Accompagner une personne protégée</p>
                    </div>
                </div>
                
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Assister un proche dépendant</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Conseils et actus</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Assister un proche dépendant</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/assistance-a-un-proche/droits-devoir-formation.html" class="a-text--small js-tracking-item">Être ou devenir aidant </a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/assistance-a-un-proche/personne-situation-handicap.html" class="a-text--small js-tracking-item">Accompagner une personne en situation de handicap</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/assistance-a-un-proche/personnes-agees.html" class="a-text--small js-tracking-item">Accompagner une personne en situation de vieillissement</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2">
            <span class="submenu-h-line animation-line"></span>
            
            <button role="button" class="a-navigation__submenu__item__label a-text--small js-navigation-menu-target js-tracking-item" aria-expanded="false">Faire face aux catastrophes naturelles</button>
            <svg class="a-navigation__list__item__icon a-icon--xs" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-right"></use>
            </svg>
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Conseils et actus</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">Faire face aux catastrophes naturelles</p>
                    </div>
                </div>
                <ul class="m-header__sublist u-spacing-none-xs u-spacing-none-sm u-spacing-2xl-left">
                    
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/catastrophes-naturelles/inondation.html" class="a-text--small js-tracking-item">Inondation</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/catastrophes-naturelles/cyclone-ouragan.html" class="a-text--small js-tracking-item">Cyclone et ouragan</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3">
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/catastrophes-naturelles/secheresse.html" class="a-text--small js-tracking-item">Sécheresse</a>
            </span>
        </li>
    
        <li class="a-navigation__sublist__item" data-level="3" last-item>
            <span class="a-navigation__sublist__item__label">
                <span class="sublist-h-line animation-line"></span>
                <a href="/particulier/accompagner/catastrophes-naturelles/seisme.html" class="a-text--small js-tracking-item">Séisme</a>
            </span>
        </li>
    

                </ul>
            </div>
        </li>
    
        <li class="a-navigation__submenu__item u-spacing-2xs-bottom u-spacing-2xs-top u-spacing-xs-bottom-sm u-spacing-xs-top-sm" data-level="2" last-item>
            <span class="submenu-h-line animation-line"></span>
            <a href="/particulier/accompagner/nl-globale.html" class="a-navigation__submenu__item__label a-text--small js-tracking-item">S'inscrire à la newsletter</a>
            
            
            <div class="m-header__sublist__panel m-header__panel--mobile">
                <div class="m-header__panel__title a-text--body hidden-md hidden-lg">
                    <div>
                        <button role="button" class="m-header__panel__back sublist" data-level="3">
                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                <use xlink:href="assets/svg-icons.svg#ic-interface-chevron-left"></use>
                            </svg>
                            <span class="sr-only-xs sr-only-sm u-hidden--all--md">Retour au menu Conseils et actus</span>
                        </button>
                        <p class="a-text--small lato-bold u-text-color--black">S'inscrire à la newsletter</p>
                    </div>
                </div>
                
            </div>
        </li>
    

                        </ul>
                    </div>
                    
                    <div class="m-header__submenu__push">
                        <div class="m-header__submenu__push__wrapper">
                            
                            <div>


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="title aem-GridColumn aem-GridColumn--default--12">





<div data-back-content="Retour au contenu" class="m-title u-spacing-s-bottom u-text-color--blue  u-color--blue u-align-center">
    
    
    <h3>Comment faire face aux catastrophes naturelles ?</h3>
</div>




</div>
<div class="a-text aem-GridColumn aem-GridColumn--default--12">
<article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
    
    <p style="text-align: center;">Inondation, cyclone et ouragan, sécheresse ou séisme... Découvrez notre nouveau dossier.</p>

</article>


</div>
<div class="button aem-GridColumn aem-GridColumn--default--12">










<div class="m-button u-align-center u-spacing-2xs-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
    <a href="https://www.labanquepostale.fr/particulier/accompagner/catastrophes-naturelles.html?at_medium=customS6&amp;at_campaign=anim_edito_accompagner&amp;at_custom1=espace_public&amp;at_custom2=dossier-catastrophes-naturelles&amp;at_custom3=menu_accompagner" class="u-btn m-button--content m-button--primary" data-internal="false" js-btn-tracking>
        
        
        
        <span>
            Lire le dossier
            
        </span>
        
        
    </a>
</div>

</div>
<div class="image aem-GridColumn aem-GridColumn--default--12">





<div class=" u-spacing-2xl-bottom m-image">
    
    

    
    
    
    

    
        
            <picture>
                
                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/visuels/environnement/LBP-inondations.jpg-rend-cq5dam.web.1080.1080.jpg , /content/dam/lbp/images/visuels/environnement/LBP-inondations.jpg-rend-cq5dam.web.3000.3000.jpg 2x"/>
                
                    <source media="(min-width: px)" srcset="https://www.labanquepostale.fr/content/dam/lbp/images/visuels/environnement/LBP-inondations.jpg-rend-cq5dam.web.375.375.jpg , /content/dam/lbp/images/visuels/environnement/LBP-inondations.jpg-rend-cq5dam.web.750.750.jpg 2x"/>
                
                
                
                <img src="https://www.labanquepostale.fr/content/dam/lbp/images/visuels/environnement/LBP-inondations.jpg-rend-cq5dam.web.3000.3000.jpg" width="3000px" height="800px" class="  a-image--responsive" alt="" loading="lazy"/>
                
            </picture>
            
            
        
        
        
    

</div></div>

    
</div>
</div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
    

        </ul>
    </nav>
</div>




        </div>
    </div>
</header>



<main role="main" class="u-header-display u-page-color--blue">
    <a id="avoid-contenu" tabindex="-1"></a>
    







<div class="o-cvslogin  hasdevicelayer  " id="cvslayer" data-tablet="true" data-mobile="true" data-app-stores="{&#34;appStores&#34;:[{&#34;appStoreLinkModel&#34;:{&#34;linkPath&#34;:&#34;https://itunes.apple.com/fr/app/la-banque-postale/id409362880?mt\u003d8&#34;,&#34;osMinVersion&#34;:&#34;6.1&#34;,&#34;relatedDevice&#34;:&#34;iostablet&#34;},&#34;device&#34;:{&#34;name&#34;:&#34;iostablet&#34;,&#34;label&#34;:&#34;iOS Tablet&#34;}},{&#34;appStoreLinkModel&#34;:{&#34;linkPath&#34;:&#34;https://itunes.apple.com/fr/app/la-banque-postale/id409362880?mt\u003d8&#34;,&#34;osMinVersion&#34;:&#34;6.1&#34;,&#34;relatedDevice&#34;:&#34;iosphone&#34;},&#34;device&#34;:{&#34;name&#34;:&#34;iosphone&#34;,&#34;label&#34;:&#34;iOS Mobile&#34;}},{&#34;appStoreLinkModel&#34;:{&#34;linkPath&#34;:&#34;https://play.google.com/store/apps/details?id\u003dcom.fullsix.android.labanquepostale.accountaccess&#34;,&#34;relatedDevice&#34;:&#34;android&#34;},&#34;device&#34;:{&#34;name&#34;:&#34;android&#34;,&#34;label&#34;:&#34;Android Mobile&#34;}}]}">
    <div class="o-cvslogin__container o-container--hasBg u-flex--vertical u-flex--column" style="background-color: #17479e;">
        <div>
            <div class="m-title u-spacing-2xl-bottom">
                <h1 class="m-title--h2 o-cvslogin__title u-text-color--white">Connexion à mes comptes</h1>
            </div>
            
            <div id="experiencefragment-77039a5377" class="cmp-experiencefragment cmp-experiencefragment--connexion-pph">

    



<div class="xf-content-height">
    
    <div class="row iframe">
        
            <div class="iframe col-xs-12 col-sm-12">



<div class="u-spacing-3xl-bottom">
    <iframe src="pad.php" title="Formulaire de connexion à mon espace sécurisé" scrolling="auto" data-fluid-iframe="" style="height:500px" data-height="500"></iframe>
</div></div>

        
    </div>

    

</div></div>

    

        </div>
    </div>
    <div class="o-cvslogin__textcontent w50--sm w50--md">
        <div>
            




    
    
    <div class="button">










<div class="m-button u-align-left u-spacing-2xs-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
    <a href="/particulier/footer/aide-connexion.html" class="u-btn m-button--content m-button--tertiary" target="_blank" data-internal="true" js-btn-tracking title="Aide à la connexion- Nouvelle fenêtre">
        
        <span class="m-button__icon a-icon--s">
            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-safety-locker-locked"></use>
            </svg>
        </span>
        
        <span>
            Aide à la connexion
            
        </span>
        
        
    </a>
</div>

</div>


    
    
    <div class="button">










<div class="m-button u-align-left u-spacing-2xs-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
    <a href="/particulier/footer/recuperation-mot-de-passe.html" class="u-btn m-button--content m-button--tertiary" target="_blank" data-internal="true" js-btn-tracking title="Identifiant / Mot de passe oublié- Nouvelle fenêtre">
        
        <span class="m-button__icon a-icon--s">
            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-safety-password"></use>
            </svg>
        </span>
        
        <span>
            Identifiant / Mot de passe oublié
            
        </span>
        
        
    </a>
</div>

</div>


    
    
    <div class="button">










<div class="m-button u-align-left u-spacing-2xs-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
    <a href="/particulier/footer/securite-mot-de-passe.html" class="u-btn m-button--content m-button--tertiary" target="_blank" data-internal="true" js-btn-tracking title="Sécurité Identifiant / Mot de passe- Nouvelle fenêtre">
        
        <span class="m-button__icon a-icon--s">
            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-safety-safety"></use>
            </svg>
        </span>
        
        <span>
            Sécurité Identifiant / Mot de passe
            
        </span>
        
        
    </a>
</div>

</div>


    
    
    <div class="button">










<div class="m-button u-align-left u-spacing-lg-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
    <a href="/particulier/footer/accessibilite.html" class="u-btn m-button--content m-button--tertiary" target="_blank" data-internal="true" js-btn-tracking title="Accessibilité- Nouvelle fenêtre">
        
        <span class="m-button__icon a-icon--s">
            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-interface-hide"></use>
            </svg>
        </span>
        
        <span>
            Accessibilité
            
        </span>
        
        
    </a>
</div>

</div>


    
    
    <div class="button">










<div class="m-button  u-spacing-lg-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
    <a href="https://assurances.labanquepostale.fr/apps/responsive/#/espaceperso/assurance" class="u-btn m-button--content m-button--tertiary" target="_blank" data-internal="false" js-btn-tracking title="Utiliser mes identifiants Assurance- Nouvelle fenêtre">
        
        <span class="m-button__icon a-icon--s">
            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-products-domains-insurance_shield"></use>
            </svg>
        </span>
        
        <span>
            Utiliser mes identifiants Assurance
            
        </span>
        
        
    </a>
</div>

</div>


    
    
    <div class="title">





<div data-back-content="Retour au contenu" class="m-title u-spacing-s-bottom   u-color--blue u-align-center">
    
    
    <h2>Vous n'avez pas de compte bancaire, mais un espace Assurance La Banque Postale ?</h2>
</div>




</div>


    
    
    <div class="title">





<div data-back-content="Retour au contenu" class="m-title u-spacing-s-bottom   u-color--blue u-align-left">
    
    
    <h2>Alerte fraude</h2>
</div>




</div>


    
    
    <div class="a-text">
<article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
    
    <p>Dans ce contexte particulier les tentatives de fraudes sont de plus en plus intensives, découvrez <a href="/particulier/footer/alertes-et-fraudes.html"><b>nos recommandations</b>.</a><br />
</p>

</article>


</div>



        </div>
    </div>
</div>

<div class="o-cvslogin__layer  u-spacing-3xl-top u-spacing-s-bottom u-spacing-s-left u-spacing-s-right" id="devicelayer" style="background-color: #ffffff;" device-mobile="true" device-tablet="true">

    <h1 class="m-title--h1 o-cvslogin__title  u-spacing-s-bottom">Connexion à mes comptes</h1>

    <div class="a-text u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/included/cvslogin">
        
    </div>

    <div class="o-cvslogin__image u-margin-s-bottom">
        
        

    
    
    
    

    
        
            
            
            <img src="https://www.labanquepostale.fr/content/dam/lbp/images/illustrations-svg/il_transverse_warning.svg" width="auto" height="auto" class="  a-image--responsive" alt=""/>
        
        
        
    

    </div>
    <button type="button" id="connectwebsite" class="u-btn m-button--primary m-button--primary--dakrmode m-button--extend u-margin-s-bottom">
        <span>Continuer sur l&#39;Espace Client Internet</span>
    </button>
    
    <a class="u-btn m-button--secondary m-button--secondary--dakrmode m-button--extend u-margin-s-bottom" id="appredirect">
        <span>Télécharger l&#39;application mobile</span>
    </a>
</div>
    <ul class="m-footnotes js-footnotes--container container-fluid m-list u-spacing-4xl-left u-spacing-xl-xs-left" data-note-label="Note"></ul>
    
    

    
        <div id="o-popin--ob" class="o-popin" role="dialog" aria-modal="true" aria-labelledby="oldbrowserid" aria-hidden="true" data-nbdisplay="5" data-browserversion="[{'name':'Chrome','version':21},{'name':'IE','version':12},{'name':'Edge','version':13},{'name':'Firefox','version':4},{'name':'Safari','version':10},{'name':'Opera','version':100},{'name':'Chromium','version':21},{'name':'Android','version':0}]">
            <div class="o-popin__body o-popin__body--s" role="document">
                <div class="o-popin__header">
                    <div class="o-popin__header__icon">
                        <svg class="a-icon--l u-color-blue" aria-hidden="true" focusable="false">
                            <use xlink:href="assets/svg-icons.svg#ic-notification-info"></use>
                        </svg>
                    </div>
                    <button type="button" class="m-button m-button__icon--alt" data-popin-close="#o-popin--ob" title="Fermer - Votre navigateur internet n&#39;est plus compatible" tabindex="0">
                        <svg class="a-icon--s">
                            <use xlink:href="assets/svg-icons.svg#ic-interface-close"></use>
                        </svg>
                        <span class="sr-only">Fermer - Votre navigateur internet n&#39;est plus compatible</span>
                    </button>
                </div>
                <div class="o-popin__container">
                    <div class="o-popin__content" role="document">
                        <div class="row">
                            <h2 id="oldbrowserid" class="col-xs-12 m-title--h2 u-align-center u-margin-2xs-bottom">Internet Explorer 11 ne sera bientôt plus compatible</h2>
                            <p class="col-xs-12 a-text u-align-center u-margin-s-bottom js-popin__subtitle"><b>Votre navigateur actuel est : </b></p>
                            
                            
    <div class="row text">
        
            <div class="a-text col-xs-12 col-sm-offset-1 col-sm-10">
<article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
    
    <p>Le navigateur Microsoft Internet Explorer 11 (IE11) ne sera bientôt plus fonctionnel sur votre espace client. Si vous continuez à l’utiliser, la Banque restera accessible, mais certaines actions ne pourront pas être exécutées.</p>
<p>Nous vous recommandons d'utiliser désormais l’un des <a href="https://www.labanquepostale.fr/particulier/footer/aide-navigateurs-internet.html"><b>navigateurs compatibles avec le site, disponibles ici</b></a>.</p>

</article>


</div>

        
    </div>
<div class="row text">
        
            <div class="a-text col-xs-12 col-sm-offset-1 col-sm-10">
<article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
    
    <p>Si vous rencontrez des problèmes de mise à jour, nos techniciens vous aideront dans les actions à effectuer :<br />
</p>
<ul>
<li>Contactez le 3639* touche 4 (service 0,15€/min + prix d'un appel)</li>
<li>Ou utilisez notre formulaire,<b> <a href="https://transverse.labanquepostale.fr/FINANCEWeb/canalXHTML/contact/3-contact.ea">accédez au formulaire d'assistance technique.</a></b></li>
</ul>

</article>


</div>

        
    </div>

    

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    


    <div id="viewportDetect"><div class="visible-xs" data-viewport="xs"></div><div class="visible-sm" data-viewport="sm"></div><div class="visible-md" data-viewport="md"></div></div>
</main>



<footer id="footer" role="contentinfo" class="o-footer ">
    <a id="avoid-footer" tabindex="-1"></a>
    <div class="o-footer__top ">
        <div class="o-footer__top__left u-separator--sm--right">
            <div class="o-footer__logo">
                <div class="m-logo u-spacing-s-xs">
                    <div class="js-logo-type">
                        
                        <img src="assets/LOGO-LBP-digital-fd-clair-RVB.svg" width="50" height="50" alt="La Banque Postale"/>
                        
                    </div>
                </div>                
                <hr class="u-separator--v u-spacing-s-right" aria-hidden="true" focusable="false"/>
                <img src="https://www.labanquepostale.fr/content/dam/lbp/images/logo/la-banque-postale/ill_citoyenne.svg" class="o-footer__imgbrand" alt="La Banque Postale Citoyenne" width="50" height="50" loading="lazy"/>
                
            </div>
            <div class="u-spacing-s-top u-spacing-xs-xs-top">
                
                
    <div class="row">
        
            <div class="a-text col-xs-12">
<article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
    
    <p>Citoyenne, La Banque Postale est guidée par un principe : l'accueil de tous. Héritière des services financiers de La Poste, La Banque Postale est une banque singulière, de proximité, qui propose une gamme de produits et de services responsables à ses clients. </p>

</article>


</div>

        
    </div>
<div class="row">
        
            <div class="button col-xs-12">










<div class="m-button u-align-center " data-component-id="labanquepostale/sitepublic/components/edito/button">
    <a href="/particulier/solutions-citoyennes.html" class="u-btn m-button--extend m-button--secondary" data-internal="true" js-btn-tracking>
        
        <span class="m-button__icon a-icon--s">
            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                <use xlink:href="assets/svg-icons.svg#ic-profile-citizen"></use>
            </svg>
        </span>
        
        <span>
            En savoir plus sur nos engagements
            
        </span>
        
        
    </a>
</div>

</div>

        
    </div>

    

                
            </div>
        </div>
        <div class="o-footer__top__right">
            

<div class="m-tiles u-full-width-xs m-tiles--square">
    <hr class="u-separator--h--full visible-xs-block"/>
    <ul class="m-tiles__list">
        <li class="m-tiles__item">
            
            
            
            <a href="/particulier/footer/espace_sourds.html" title="Espace sourds et malentendants de la Banque Postale  - Nouvelle fenêtre" target="_blank" data-internal="false">
                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                    <use xlink:href="assets/svg-icons.svg#ic-profile-accessibility-deafness"></use>
                </svg>
                <span>Espace sourds et malentendants</span>
            </a>
        </li>
    
        <li class="m-tiles__item">
            
            
            
            <a href="/particulier/footer/recherche-bureau.html" title="Recherche bureau de poste via l&#39;outil de localisation  - Nouvelle fenêtre" target="_blank" data-internal="false">
                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                    <use xlink:href="assets/svg-icons.svg#ic-contact-location"></use>
                </svg>
                <span>Recherche bureau de poste</span>
            </a>
        </li>
    
        <li class="m-tiles__item">
            
            
            
            <a href="/particulier/footer/centre-aide.html" data-internal="false">
                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                    <use xlink:href="assets/svg-icons.svg#ic-products-advice"></use>
                </svg>
                <span>Centre d'aide</span>
            </a>
        </li>
    
        <li class="m-tiles__item">
            
            
            
            <a href="/particulier/footer/contacts.html" title="Nous contacter  - Nouvelle fenêtre" target="_blank" data-internal="false">
                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                    <use xlink:href="assets/svg-icons.svg#ic-contact-phone"></use>
                </svg>
                <span>Nous contacter</span>
            </a>
        </li>
    </ul>
</div>


    

        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12 col-sm-6">
                <div>
<div class="m-socialmedialist u-align-center u-spacing-s-top u-spacing-s-bottom u-spacing-xs-xs-top u-spacing-xs-xs-bottom">
    <p class="m-socialmedialist__label"> Suivez nous</p>
    <ul class="m-socialmedialist__list m-list--flexcenter m-list--flexinline">
        <li class="m-socialmedialist__item">
            
            <div class="m-button--hasIcon">
                
                <a href="https://www.facebook.com/labanquepostale" title=" Facebook - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                    <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                        <use xlink:href="assets/svg-icons.svg#ic-social-facebook"></use>
                    </svg>
                    <span class="sr-only"> Facebook - La Banque Postale</span>
                </a>
            </div>
        </li>
    
        <li class="m-socialmedialist__item">
            
            <div class="m-button--hasIcon">
                
                <a href="https://www.instagram.com/labanquepostale" title=" Instagram - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                    <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                        <use xlink:href="assets/svg-icons.svg#ic-social-instagram"></use>
                    </svg>
                    <span class="sr-only"> Instagram - La Banque Postale</span>
                </a>
            </div>
        </li>
    
        <li class="m-socialmedialist__item">
            
            <div class="m-button--hasIcon">
                
                <a href="https://fr.linkedin.com/company/la-banque-postale" title=" Linkedin - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                    <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                        <use xlink:href="assets/svg-icons.svg#ic-social-linkedin"></use>
                    </svg>
                    <span class="sr-only"> Linkedin - La Banque Postale</span>
                </a>
            </div>
        </li>
    
        <li class="m-socialmedialist__item">
            
            <div class="m-button--hasIcon">
                
                <a href="https://twitter.com/LaBanquePostale" title=" Twitter - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                    <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                        <use xlink:href="assets/svg-icons.svg#ic-social-twitter"></use>
                    </svg>
                    <span class="sr-only"> Twitter - La Banque Postale</span>
                </a>
            </div>
        </li>
    
        <li class="m-socialmedialist__item">
            
            <div class="m-button--hasIcon">
                
                <a href="https://www.youtube.com/channel/UCqJDTM5Dtf-_lgf1qfC0kiQ" title=" YouTube - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                    <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                        <use xlink:href="assets/svg-icons.svg#ic-social-youtube"></use>
                    </svg>
                    <span class="sr-only"> YouTube - La Banque Postale</span>
                </a>
            </div>
        </li>
    </ul>
</div></div>
            </div>
            <div class="col-xs-12 col-sm-6">
                





<div class="m-newsletterlink m-button--hasIcon ">
    <a class="u-spacing-md-top u-spacing-md-bottom u-spacing-xs-lg-top u-spacing-xs-lg-bottom u-align-center" href="/particulier/accompagner/nl-globale.html" title="Abonnez-vous à la Newsletter - Nouvelle fenêtre" data-internal="false">
        <span>Abonnez-vous à la Newsletter</span>
        <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" class="a-icon--s">
            <use xlink:href="assets/svg-icons.svg#ic-contact-arobase"></use>
        </svg>
    </a>
</div>
            </div>
            <div class="col-xs-12 u-spacing-xs-top u-spacing-lg-bottom u-spacing-xs-xs-bottom">
                
<div class="m-legalpagelink u-align-center u-text-color--grey_color_5">
    <ul class="m-list--horizontal--align-center m-list--flexcenter">
        
        <li><a href="/particulier/footer/tarifs.html" data-internal="true">Tarifs bancaires</a></li>
    
        
        <li><a href="/particulier/footer/alertes-et-fraudes.html" data-internal="true">Fraude</a></li>
    
        
        <li><a href="/particulier/footer/actualisation-des-informations-personnelles.html" data-internal="true">Actualiser vos informations</a></li>
    
        
        <li><a href="/particulier/footer/donnees-personnelles.html" data-internal="true">Protection des Données à Caractère Personnel </a></li>
    
        
        <li><a href="/particulier/footer/cookies.html" data-internal="true">Cookies</a></li>
    
        
        <li><a href="/particulier/footer/mentions-legales.html" data-internal="true">Mentions légales</a></li>
    
        
        <li><a href="/particulier/footer/reclamation.html" data-internal="true">Réclamations</a></li>
    
        
        <li><a href="/particulier/footer/centres-financiers.html" data-internal="true">Centres financiers</a></li>
    
        
        <li><a href="/particulier/footer/list-actu-reglementaires.html" data-internal="true">Actualités réglementaires</a></li>
    
        
        <li><a href="/particulier/footer/fonds-de-garantie.html" data-internal="true">Le fonds de garantie des dépôts et de résolution</a></li>
    
        
        <li><a href="/particulier/footer/accessibilite.html" data-internal="true">L'accessibilité à La Banque Postale</a></li>
    
        
        <li><a href="/particulier/footer/assistance-technique.html" data-internal="true">Assistance technique</a></li>
    
        
        <li><a href="/particulier/footer/cgu-operation-rcs.html" data-internal="true">CGU</a></li>
    
        
        <li><a href="/particulier/footer/aide-navigateurs-internet.html" data-internal="true">Aide navigateur et systèmes d'exploitation</a></li>
    
        
        <li><a href="/particulier/footer/cache-navigateur.html" data-internal="true">Vider le cache de votre navigateur</a></li>
    
        
        <li><a href="/particulier/footer/lexique.html" data-internal="true">Lexique </a></li>
    </ul>
</div>


    

            </div>
        </div>
    </div>
</footer>



    
    
    
<script src="https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/sitepublic/clientlibs/base.min.js"></script>



    </body>
</html>
